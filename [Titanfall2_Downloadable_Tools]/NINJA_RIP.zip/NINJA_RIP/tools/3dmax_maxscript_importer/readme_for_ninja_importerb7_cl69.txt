I have modified the 3DS Max script. It now includes a progress bar and can import over 2,000 objects in little over a minute on my computer.

Changes that I made:

- You can now flip on the XZ axis if your models appear inverted!
- Added progress bar
- Removed a lot of unnecessary information being printed
- End of script will show a popup message with how long it took to import
- "Debug" mode allows you to turn on useless print messages, VERY SLOW.
- Program no longer hangs when importing many objects :D
- Imports are now 50 - 75% faster. I was able to import 2,001 objects in 1 minute and 30 seconds!

Download: https://dl.dropbox.com/u/69162797/misc/ ... b7_cl69.ms
Script modified with 3ds Max 2011!

Please leave bug reports or feedback here in this current thread. I may consider feature requests if it is feasible and within my capabilities.

Enjoy!